// validates form inputs
function validate_form_inputs(inputs, selector = "#") {
  let inputs_value = {};
  for (input of inputs) {
    let value = null;
    try {
      value = $(`${selector}${input}`).val().trim();
      value = value === "null" ? null : value;
    } catch (error) {
      value = $(`${selector}${input}`).val();
    }

    if (value == "" || value == null) {
      $(`${selector}${input}`).css("border", "1px solid red");
      $(`${selector}${input}`).focus();
      Snackbar.show({
        text: `the ${input} field is required`,
        pos: "top-right",
        actionTextColor: "#fff",
        backgroundColor: "#e7515a",
        duration: 3000,
      });
      inputs_value = null;
      break;
    } else {
      $(`${selector}${input}`).css("border", "1px solid rgba(0,0,0,.2)");
      error = true;
      inputs_value[input] = $(`${selector}${input}`).val();
    }
  }
  return inputs_value;
}

function Alert(msg, bg = "#e7515a") {
  Snackbar.show({
    text: msg,
    pos: "top-right",
    actionTextColor: "#fff",
    backgroundColor: bg,
    duration: 3000,
  });
}

function input_values(inputs, selector = "#") {
  let inputs_value = {};
  for (input of inputs) {
    let value = null;
    try {
      value = $(`${selector}${input}`).val().trim();
      value = value === "null" ? null : value;
    } catch (error) {
      value = $(`${selector}${input}`).val();
    }
    inputs_value[input] = $(`${selector}${input}`).val();
  }
  return inputs_value;
}

function base_url() {
  return `http://${location.host}`;
}

async function load(url) {
  // load_spinner("show");
  return await fetch(`/${url}`)
    .then((res) => {
      // load_spinner("hide");
      return res.json();
    })
    .catch((e) => console.log(e));
}

async function _load(url, data) {
  load_spinner("show");
  return await fetch(`/${url}`, {
    method: "POST",
    mode: "cors",
    cache: "no-cache",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    redirect: "follow",
    referrerPolicy: "no-referrer",
    body: JSON.stringify(data),
  })
    .then((res) => {
      load_spinner("hide");
      return res.json();
    })
    .catch((e) => console.log(e));
}

function load_data(url) {
  let data = null;
  $.ajax({
    type: "GET",
    url: `/${url}`,
    dataType: "JSON",
    async: false,
    success: function (response) {
      data = response;
    },
  });
  return data;
}

function make_special_id(prefix, size, id) {
  let zeros = "";
  let s = 0;
  while (s < size) {
    zeros += "0";
    s++;
  }
  if (zeros.length < String(id).split("").length) {
    return prefix + id;
  }
  return (
    prefix + zeros.substr(0, zeros.length - String(id).split("").length) + id
  );
}

function set(object, selector = "#") {
  let keys = Object.keys(object);
  for (key of keys) {
    $(`${selector}${key}`).val(object[key]);
  }
}

function unset(inputs, selector = "#") {
  inputs.forEach((input) => {
    if ($(`${selector}${input}`).attr("type") !== undefined) {
      $(`${selector}${input}`).val(null);
    } else {
      $(`${selector}${input} option:first`).prop("selected", true);
      $(`${selector}${input}`).val("null").trigger("change");
    }
    $(`${selector}${input}`).css("border", "1px solid rgba(0,0,0,.2)");
  });
}

function sum_of_a_column(arr, target, float = 2) {
  let total = 0;
  for (value of arr) {
    let td = $(value).children("td")[target];
    if ($(td).children().length > 0) {
      total += Number($($(td).children()[0]).val());
    } else {
      total += Number($(td).text());
    }
  }
  return rnd_num(total, float);
}

function sum(arr, target, float = 2) {
  let total = 0;
  for (value of arr) {
    total += Number(value[target]);
  }
  return rnd_num(total, float);
}

function rnd_num(value, round = 2) {
  if (value.toString().length > round) {
    return Number(Number(value).toFixed(round));
  }
  return Number(value);
}

function display_rnd(value, round = 2) {
  if (value.toString().length > round) {
    return Number(Number(value).toFixed(round));
  }
  return Number(value);
}

function update_footer(object, selector = "#") {
  let keys = Object.keys(object);
  for (key of keys) {
    $(`${selector}${key}`).text(object[key]);
  }
}

function loading_button(button, state) {
  // let btn = Ladda.create(document.querySelector(button));
  // state === "loading" ? btn.start() : btn.stop();
  let btn = $(button);
  state === "loading"
    ? btn.prop("disabled", true)
    : btn.prop("disabled", false);
}

function load_spinner(state) {
  // $.fakeLoader({
  //   loading: state,
  // });
  return "";
}

String.prototype.capitalize = function () {
  return this.split(" ")
    .map((word) => `${word.charAt(0).toUpperCase()}${word.substr(1)}`)
    .join(" ");
};

Array.prototype.first = function () {
  return this[0];
};

Array.prototype.insert = function (index, ...element) {
  this.splice(index, 0, ...element);
  return this;
};

Number.prototype.amount = function () {
  return this.toFixed(2);
};

String.prototype.toFloat = function (round = 2) {
  return Number(Number(this.replace(/\$|,/g, "")).toFixed(round));
};

Array.prototype.last = function () {
  return this[this.length - 1];
};

function number_with_commas(number) {
  let parts = number.toString().split('.')
  return `${parts[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}.${parts[1] ?? 0}`;
}

function get_request(name) {
  if (
    (name = new RegExp("[?&]" + encodeURIComponent(name) + "=([^&]*)").exec(
      location.search
    ))
  )
    return decodeURIComponent(name[1]);
} 

function current_date() {
  let date = new Date();
  let month = date.getMonth() + 1;
  month = month < 10 ? `0${month}` : month;
  let day = date.getDate() < 10 ? `0${date.getDate()}` : date.getDate();
  return `${day}-${month}-${date.getFullYear()}`;
  // return moment(new Date()).format("DD-MM-YYYY");
}

function date_diff(start, end, state = "days") {
  start = moment(start, "'DD/MM/YYYY");
  end = moment(end, "'DD/MM/YYYY");
  return end.diff(start, state);
}

function convert_to_date(string) {
  let date = string.split("-");
  return new Date(`${date[2]}-${date[1]}-${date[0]}`);
}

function system_setup_date() {
  // let system_setup_date = sessionStorage.getItem("setup_date");
  // if (true) {
  //   load("system/setup_date").then((res) => {
  //     sessionStorage.setItem("setup_date", convert_to_date(res.data));
  //   });
  // }
  // return sessionStorage.getItem("setup_date");
  return "01-01-2021";
}

function close_trow(dataTable, current) {
  let index = dataTable.row($(current).closest("tr")).index();
  if (index === undefined) {
    index = dataTable.row(current).index();
  }
  return index;
}

function toWordsconver(s) {
  var th_val = ["", "thousand", "million", "billion", "trillion"];

  var dg_val = [
    "zero",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine",
  ];
  var tn_val = [
    "ten",
    "eleven",
    "twelve",
    "thirteen",
    "fourteen",
    "fifteen",
    "sixteen",
    "seventeen",
    "eighteen",
    "nineteen",
  ];
  var tw_val = [
    "twenty",
    "thirty",
    "forty",
    "fifty",
    "sixty",
    "seventy",
    "eighty",
    "ninety",
  ];
  s = s.toString();
  s = s.replace(/[\, ]/g, "");
  if (s != parseFloat(s)) return "not a number ";
  var x_val = s.indexOf(".");
  if (x_val == -1) x_val = s.length;
  if (x_val > 15) return "too big";
  var n_val = s.split("");
  var str_val = "";
  var sk_val = 0;
  for (var i = 0; i < x_val; i++) {
    if ((x_val - i) % 3 == 2) {
      if (n_val[i] == "1") {
        str_val += tn_val[Number(n_val[i + 1])] + " ";
        i++;
        sk_val = 1;
      } else if (n_val[i] != 0) {
        str_val += tw_val[n_val[i] - 2] + " ";
        sk_val = 1;
      }
    } else if (n_val[i] != 0) {
      str_val += dg_val[n_val[i]] + " ";
      if ((x_val - i) % 3 == 0) str_val += "hundred ";
      sk_val = 1;
    }
    if ((x_val - i) % 3 == 1) {
      if (sk_val) str_val += th_val[(x_val - i - 1) / 3] + " ";
      sk_val = 0;
    }
  }
  if (x_val != s.length) {
    var y_val = s.length;
    str_val += "point ";
    for (var i = x_val + 1; i < y_val; i++) str_val += dg_val[n_val[i]] + " ";
  }
  return str_val.replace(/\s+/g, " ");
}

function globalDataTableOptions() {
  return {
    dom:
      "<'dt--top-section'<'row'<'col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3'f>>>" +
      "<'table-responsive'tr>" +
      "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
    oLanguage: {
      oPaginate: {
        sPrevious:
          '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
        sNext:
          '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>',
      },
      sInfo: "Showing page _PAGE_ of _PAGES_",
      sSearch:
        '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
      sSearchPlaceholder: "Search...",
      sLengthMenu: "Results :  _MENU_",
    },
    stripeClasses: [],
    lengthMenu: [7, 10, 20, 50],
    pageLength: 50,
    order: [],
  };
}

function newBtnToggle(el) {
  let toggle = $(el).data("toggle");
  if (toggle === "list") {
    $("#list, button.record_btn").hide();
    $("#form, button.list_btn").show();
    $(el).data("toggle", "new");
  } else if (toggle === "new") {
    $("#list, button.record_btn").show();
    $("#form, button.list_btn").hide();
    $(el).data("toggle", "list");
  }
  return toggle;
}

$(document).ready(function () {
  $(".name").css("text-transform", "capitalize");
  $(".address").css("text-transform", "capitalize");
  $(".city").css("text-transform", "capitalize");

  $("#div_loading").appendTo("html");

  // input type number
  $(document).on("keyup", 'input[type="number"]', function () {
    if (
      Number($(this).val()) < 0 &&
      $(this).data("balance") !== "begining_balance"
    ) {
      $.toast({
        heading: "Invalid entry",
        text: `this can not be less than zero`,
        icon: "error",
        position: "top-right",
      });
      $(this).val(0);
    }
  });

  // table new btn click
  $(document).on("click", "li.paginate_button", function () {
    check_role();
  });

  // table new btn click
  $(document).on(
    "input",
    "div.dataTables_filter input[type='search']",
    function () {
      run_role();
    }
  );

  $(document).on("order.dt", function () {
    check_role();
  });
});

function run_role() {
  check_role();
}
