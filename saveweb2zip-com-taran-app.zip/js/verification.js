$(document).ready(function () {
    $("button.check_verif").click(function (e) {    
        e.preventDefault();
        let validate = validate_form_inputs(is_customer_registered ? ["verification_code"] : ["fullName", "verification_code"]);
        if (validate) {
            validate["phone"] = $("#phone_number").val();
            validate["fullName"] = $("#fullName").val();
            validate["verification_code"] = $("#verification_code").val();
            validate["transaction_code"] = trans_code;
            validate["is_customer_registered"] = is_customer_registered;

            $.ajax({
                type: "POST",
                url: "/client/customer/check_kyc_name",
                data: JSON.stringify(validate),
                dataType: "JSON",
                async: true,
                success: function (response) {
                    $(".verif_error").hide();
                    $("#verification_code").css("border", "1px solid rgba(0,0,0,.3)");

                    if (response.error) {
                        $(".verif_error").show().text(response.error.split('-').join(' '));
                        $("#verification_code").css("border", "1px solid red");
                    } else {
                        $('#verificationModel').modal('hide')
                        withdrawal_method()

                        if(!is_customer_registered) {
                            $.ajax({
                                type: "POST",
                                url: "/client/customer/store",
                                data: JSON.stringify(validate),
                                dataType: "JSON",
                                async: true,
                                success: function (response) {
                                    // console.log(response);
                                },
                            });
                        }
                    }
                },
            });
        }
    });
});
