  let currencys = [];
  let tac_check = false;

  let discount_amount = 0;
  let ponus_amount = 0;
  let affiliate_code = null;

  let trans_code = null;
  let is_customer_registered = null

  $(document).ready(function () {
    let selecting = "";
    let instruction = "";
    let proof_image = "";
    let payout_charge = 0;
    let is_approve_required = false;
    let found_transaction_id = null;
    let api_type = null;

    load("admin/currency/list").then((res) => {
      currencys = res ?? [];
    });

    $("ul.currency_list").on("click", "li", function () {
      let img = $(this).children("img").attr("src");
      let id = $(this).data("currency_id");
      let name = $(this)
        .children("div.currency")
        .find("div.currency_sign")
        .text()
        .trim();

      $(`.${selecting}_currency`).html("");
      $(`.${selecting}_currency`).append(selected_currency_el(img, name));
      $(`.${selecting}_currency`).data("currency", name);
      $(`.${selecting}_currency`).data("name", $(this).data("name"));
      $(`.${selecting}_currency`).data("id", id);
      $("#currencyModel").modal("hide");
      if (fill_buy_input()) {
        $("#buy").val($("#sell").val());
        show_sell_detail();
      }
    });

    $(".connect_btn").click(function (e) {
      e.preventDefault();
      if (fill_buy_input()) {
        if (tac_check) {
          isNoteToShow(() => {
            $("#phoneAndAccountModel").modal("show");
            $("#payment_method").children().remove();
      
            let sell_amount = Number($("#sell").val());
            for (factor of JSON.parse(
              get_currency(selected_currency("sell")).currency_factor
            )) {
              if (
                sell_amount >= Number(factor.minimum_amount) &&
                sell_amount <= Number(factor.maximum_amount)
              ) {
                is_approve_required = factor.approve;
                break;
              }
            }
      
            $("#payment_method").append(
              payment_method_option(
                JSON.parse(get_currency(selected_currency("sell")).sending_detail),
                is_approve_required
              )
            );
          })
        } else {
          Snackbar.show({
            // text: lang("alert.__SELL_AMOUNT_&_CURRENCY"),
            text: 'Please read and accept term and condition first',
            pos: "top-right",
            actionTextColor: "#fff",
            backgroundColor: "#e7515a",
            duration: 3000,
          });
        }
        // window.onbeforeunload = function (evt) {
        //   var message = "Are you sure you want to leave?";
        //   if (typeof evt == "undefined") {
        //     evt = window.event;
        //   }
        //   if (evt) {
        //     evt.returnValue = message;
        //   }
        // };
      } else {
        if (
          selected_currency("sell") === undefined ||
          $("#sell").val().trim() === ""
        ) {
          Snackbar.show({
            text: lang("alert.__SELL_AMOUNT_&_CURRENCY"),
            pos: "top-right",
            actionTextColor: "#fff",
            backgroundColor: "#e7515a",
            duration: 3000,
          });
        } else if (selected_currency("buy") === undefined) {
          Snackbar.show({
            text: lang("alert.__BUY_CURRENCY"),
            pos: "top-right",
            actionTextColor: "#fff",
            backgroundColor: "#e7515a",
            duration: 3000,
          });
        }
      }
    });

    $("#payment_method").change(function (e) {
      e.preventDefault();
      if ($(this).val() !== "null") {
        $(".phone-input").show().children().remove();
        let sltd_option = $(this).children("option:selected")
        let inputPlaceholder = `${$(this).val().toLowerCase()}`
        let inputValue = `${$(sltd_option).data("prefix")}`

        $(".phone-input").append(
          `<label for="phone_number">${$(this).val()}</label> <span class="float-right" id="amountToPay"></span>
          <input type="${$(sltd_option).data("input_type")}" data-prefix="${inputValue}" 
            class="form-control" id="phone_number" placeholder="Enter ${inputPlaceholder}" value="${inputValue}">
          `
        );
        
        instruction = $("#payment_method option:selected").data("send_guard");
      } else {
        $(".phone-input").hide();
      }
    });

    $(".phone-input").on('input', 'input#phone_number', function(){
      let value = $(this).val()
      let prefix = $(this).data('prefix')

      if (!value.startsWith(prefix)) {
        $(this).val(prefix)
      }
    })

    $("#withdrawal_method").change(function (e) {
      e.preventDefault();
      if ($(this).val() !== "null") {
        $(".account-input").show().children().remove();
        let sltd_option = $(this).children("option:selected")
        let inputPlaceholder = `${$(this).val().toLowerCase()}`
        let inputValue = `${$(sltd_option).data("prefix")}`

        $(".account-input").append(
          `<label for="account_number">${$(this).val()}</label> <span class="float-right" id="amountToReceive"></span>
            <input type="${$(sltd_option).data("input_type")}" class="form-control" id="account_number" 
            data-method_name="${$(this).val()}" data-prefix="${inputValue}" value="${inputValue}" placeholder="Enter ${inputPlaceholder}">
          `
        );
      } else {
        $(".account-input").hide();
      }
    });

    $(".account-input").on('input', 'input#account_number', function(){
      let value = $(this).val()
      let prefix = $(this).data('prefix')

      if (!value.startsWith(prefix)) {
        $(this).val(prefix)
      }
    })

    $("#sell").blur(function (e) {
      e.preventDefault();
      if (fill_buy_input()) {
        $("#buy").val($("#sell").val());
        show_sell_detail();
      }
    });

    $("#phoneAndAccountModel").on("hidden.bs.modal", function (e) {
      // e.preventDefault();
      // e.stopPropagation();
      // return false;
    });

    $("#receiptModal").on("hidden.bs.modal", function (e) {
      window.onbeforeunload = function () {};
      window.location.href = window.location.href;
    });

    $("button.next_btn").click(function (e) {
      e.preventDefault();
      let validate = validate_form_inputs(["phone_number"]);
      let prefix = String($('#phone_number').data('prefix'));
      let value = String(validate.phone_number);

      if (validate !== null && value !== prefix) {
        checkDepositProceed(validate.phone_number, () => {
          api_type = $("#payment_method option:selected").data("api_type");
          let buy_currency = selected_currency("buy");
          $(".div-phone, .next_btn").hide();
          $(".div-account, .save_btn").show();
          $('label[for="account_number"]').text(buy_currency + " Account Number");
          $("#amountToReceive").text(buy_currency + " => $" + $("#sell").val());
  
          if (!is_approve_required) {
            $("#phoneAndAccountModel").modal("hide");
            let _instruction = instruction.replace("$", $("#sell").val());
            let instruction_div = "";
            if (get_type() == "us dollar") {
              instruction_div = `<div> ${_instruction} <a href="tel:${_instruction.replace(
                "#",
                "%23"
              )}"> <i class="fas fa-phone-square text-info"></i> </a> </div>`;
            } else {
              instruction_div = `<div> ${_instruction} </div>`;
              // instruction_div = `<div> ${_instruction} <a href="market://details?id=com.PerfectMoney.package"> <i class="fas fa-phone-square text-info"></i> </a> </div>`;
            }
  
            swal({
              title: instruction_div,
              padding: "2em",
              cancelButtonText: lang("label.__BACK"),
              confirmButtonText: lang("label.__DONE"),
              showCancelButton: true,
              allowOutsideClick: false,
              // showCloseButton: true,
            }).then((result) => {
              if (result.value) {
                swal({
                  title: lang("label.__CHECKING_DEPOSITE"),
                  text: lang("alert.__DEPOSIT_CHECK"),
                  // timer: 100,
                  padding: "2em",
                  allowOutsideClick: false,
                  onOpen: function () {
                    swal.showLoading();
  
                    let type = get_api_type();
  
                    $.ajax({
                      type: "POST",
                      url: "/admin/transaction/check_deposite",
                      data: JSON.stringify({
                        amount: $("#sell").val(),
                        phone_number: $("#phone_number").val(),
                        type,
                      }),
                      dataType: "JSON",
                      success: function (response) {
                        if (response.error) {
                          Alert("An error occurred, please contact administration");
                          swal.close();
                          reset();
                        } else if (!response) {
                          // Alert(`There is no deposite from this ${$("#phone_number").val()} with amount ${$("#sell").val()}. please try again`)
                          swal.close();
                          reset();
  
                          swal({
                            title: lang("label.__DEPOSIT_NOT_FOUND"),
                            text: lang("alert.__NOT_VERIFIED_DEPOSIT"),
                            type: "error",
                            confirmButtonText: lang("label.__DONE"),
                            padding: "2em",
                            allowOutsideClick: false,
                          });
                        } else if (response.length > 0) {
                          swal.close();
  
                          if (response[0] === "pending") {
                            swal({
                              title: `Pending Transaction!`,
                              text: `This is transaction is pending and used by someone else!`,
                              type: "error",
                              confirmButtonText: lang("label.__CANCEL"),
                              padding: "2em",
                              allowOutsideClick: false,
                            }).then(() => {
                              window.location = window.location.href;
                            });
                          } else if (response[0] === "black listed") {
                            swal({
                              title: `Black Listed!`,
                              text: `This is account is black listed, please use another account!`,
                              type: "error",
                              confirmButtonText: lang("label.__CANCEL"),
                              padding: "2em",
                              allowOutsideClick: false,
                            }).then(() => {
                              window.location = window.location.href;
                            });
                          } else if (!isNaN(response[0])) {
                            found_transaction_id = response[0];
                            trans_code = response[1];
                            is_customer_registered = response[2];
                            let isPerfectMoney = response[3];
  
                            swal({
                              title: `${lang("alert.__GOOD_JOB")}!`,
                              text: `${lang("alert.__VERIFIED_DEPOSIT")}!`,
                              type: "success",
                              confirmButtonText: lang("label.__NEXT"),
                              padding: "2em",
                              allowOutsideClick: false,
                            }).then(() => {
                              if (!isPerfectMoney) {
                                $("#verif_title").append(`
                                  <h6 class="text-center">
                                    Waxaan kusoo dirnay SMS uu lasocdo Lambar sireed OTP ah si aan u xaqiijino lambarkaaga.
                                  </h4>
                                `);
    
                                is_customer_registered ? $('#verification_name').hide() : ''
                                $("#verificationModel").modal("show");
                              } else {
                                withdrawal_method()
                              }
                            });
                          }
                        }
                      },
                    });
                  },
                });
              } else {
                $("button.back_btn").click();
                $("#phoneAndAccountModel").modal("show");
              }
            });
          } else {
            $("#phoneAndAccountModel").modal("hide");
            swal({
              title: instruction.replace("$", $("#sell").val()),
              padding: "2em",
              cancelButtonText: lang("label.__BACK"),
              confirmButtonText: lang("label.__DONE"),
              showCancelButton: true,
              allowOutsideClick: false,
              // showCloseButton: true,
            }).then((result) => {
              if (result.value) {
                $("#proofModel").modal("show");
                let inputs = JSON.parse(
                  get_currency(selected_currency("sell")).transaction_proof
                );
                inputs = inputs.filter(
                  (input) => input.field_name === $("#payment_method").val()
                );
                inputs.forEach((input) => {
                  $("#proofModel .modal-body").append(file_upload());
                  $(".dropify").dropify({
                    messages: {
                      default: input.field_name,
                      replace: "Upload or Drag n Drop",
                    },
                  });
                });
              } else {
                $("button.back_btn").click();
                $("#phoneAndAccountModel").modal("show");
              }
            });
          }
        })
      } else if (validate !== null) {
        Snackbar.show({
          text: "Please complate account / phone number",
          pos: "top-right",
          actionTextColor: "#fff",
          backgroundColor: "#e7515a",
          duration: 3000,
        });
        $('#phone_number').css('border', '1px solid red').focus()
      } else {
        Snackbar.show({
          text: lang("alert.__PAYMENT_METHOD_&_NUMBER"),
          pos: "top-right",
          actionTextColor: "#fff",
          backgroundColor: "#e7515a",
          duration: 3000,
        });
      }
    });

    $("button.proof_btn").click(function (e) {
      e.preventDefault();
      let error = true;

      if ($("#proof_image")) {
        if ($("#proof_image").val() !== "") {
          proof_image = $("#proof_image").get(0).files[0];
          error = false;
        } else {
          Alert("file upload is required");
        }
      }

      // success
      if (!error) {
        $(".div-account").children().remove();
        buy_curr = JSON.parse(
          get_currency(selected_currency("buy")).sending_detail
        );

        $(".div-account").append(
          `<label for="account_number">${
            buy_curr[0].field_name
          }</label> <span class="float-right" id="amountToReceive"></span>
              <input type="text" class="form-control" id="account_number" data-method_name="${
                buy_curr[0].field_name
              }" placeholder="Enter ${buy_curr[0].field_name.toLowerCase()}">
            `
        );

        if (buy_curr.length === 1) {
          $(".div-account").append(
            `<label for="account_number">${
              buy_curr[0].field_name
            }</label> <span class="float-right" id="amountToReceive"></span>
              <input type="text" class="form-control" id="account_number" data-method_name="${
                buy_curr[0].field_name
              }" placeholder="Enter ${buy_curr[0].field_name.toLowerCase()}">
            `
          );
        }
        $("#proofModel").modal("hide");
        $("#phoneAndAccountModel").modal("show");
      }
    });

    $("button.back_btn").click(function (e) {
      e.preventDefault();
      $(".div-account, .save_btn, .back_btn").hide();
      $(".div-phone, .next_btn").show();
    });

    $("button.save_btn").click(function (e) {
      e.preventDefault();
      let validate = validate_form_inputs(["account_number"]);
      if (validate !== null) {
        checkWithdrawalProceed(validate.account_number, () => {
          let type = get_type();
  
          if (validate_account_number(validate.account_number, type)) {
            $("#phoneAndAccountModel").modal("hide");
            let data = {
              sell_currency: selected_currency("sell", "id"),
              buy_currency: selected_currency("buy", "id"),
              paying_amount: $("#sell").val(),
              charge_rate: Number($("#sell_rate").data("charge")),
              receiving_amount: $("#buy").val(),
              payment_method: $("#payment_method").val(),
              receiving_method: $("#account_number").data("method_name"),
              phone_number: $("#phone_number").val(),
              status: is_approve_required ? "pending" : "sent",
              account_number: $("#account_number").val().trim().toUpperCase(),
              inventory_account: get_currency(selected_currency("buy"))
                .product_account,
              cash_account: $("#payment_method option:selected").data("account"),
            };
  
            if (data.cash_account) {
              let form = new FormData();
              form.append("sell_currency", data.sell_currency);
              form.append("buy_currency", data.buy_currency);
              form.append("paying_amount", data.paying_amount);
              form.append("charge_rate", data.charge_rate);
              form.append("receiving_amount", data.receiving_amount);
              form.append("payment_method", data.payment_method);
              form.append("receiving_method", data.receiving_method);
              form.append("phone_number", data.phone_number);
              form.append("status", data.status);
              form.append("account_number", data.account_number);
              form.append("inventory_account", data.inventory_account);
              form.append("cash_account", data.cash_account);
              form.append("tran_id", found_transaction_id);
              form.append("type", type);
              form.append("api_type", get_api_type());
              form.append("trans_code", trans_code);
              form.append("discount_amount", discount_amount);
              form.append("ponus_amount", ponus_amount);
              form.append("affiliate_code", affiliate_code);
              form.append(
                "payout_charge",
                (Number(payout_charge) / 100) * Number(data.receiving_amount)
              );
              form.append("promo", promo_code !== null ? promo_code.code : "");
  
              // proof
              form.append("proof_image", proof_image);
  
              swal({
                title: `${lang("alert.__CHECKING_ACCOUNT_NUMBER")}`,
                text: `${lang("alert.__ACCOUNT_KYC")}!!.`,
                // timer: 100,
                padding: "2em",
                allowOutsideClick: false,
                onOpen: function () {
                  swal.showLoading();
                  $.ajax({
                    type: "GET",
                    url: `/client/check/pm_account?account=${data.account_number}&type=${type}`,
                    dataType: "JSON",
                    success: function (response) {
                      swal.close();
                      if (!response[0].includes("ERROR:")) {
                        if (response[0] === "black listed") {
                          swal({
                            title: `Black Listed!`,
                            text: `This is account is black listed, please use another account!`,
                            type: "error",
                            confirmButtonText: lang("label.__CANCEL"),
                            padding: "2em",
                            allowOutsideClick: false,
                          }).then(() => {
                            window.location = window.location.href;
                          });
                        } else {
                          form.append("destination_name", response[0]);
                          swal({
                            title: `${lang("alert.__ARE_YOU_SURE")}`,
                            html: `
                              <h6> ${lang("alert.__DEPOSITING_TO")} </h6>
                              <h6>${data.account_number}</h6>
                              <h6 style="font-weight:bold;text-transform:uppercase"> ${response[0]} </h6>
                      
                              <hr>
                              <h6> ${lang("alert.__YOUR_EXCHANGE_AMOUNT")} : ${data.paying_amount} </h6>
                              <h6> ${lang("alert.__CHARGE_PERCENTAGE")} : ${data.charge_rate} </h6>
                              <h6 style="display:${discount_amount > 0 ? 'block' : 'none'}"> ${lang("alert.__TOTAL_AMOUNT")} : ${rnd_num(data.receiving_amount - discount_amount)} </h6>
                              <h6 style="display:${discount_amount > 0 ? 'block' : 'none'}"> ${lang("alert.__DISCOUNT_PONUS")} : ${discount_amount} </h6>
                              <h6> ${lang("alert.__YOUR_PAYOUT")} : ${data.receiving_amount} </h6>
                            `,
                            showCancelButton: true,
                            confirmButtonText: lang("label.__SURE"),
                            cancelButtonText: lang("label.__CANCEL"),
                            padding: "2em",
                            allowOutsideClick: false,
                          }).then(function (result) {
                            if (found_transaction_id || is_approve_required) {
                              if (result.value) {
                                fetch("/admin/transaction/client_store", {
                                  method: "POST",
                                  body: form,
                                })
                                  .then((response) => response.json())
                                  .then((res) => {
                                    if (!res) {
                                      swal({
                                        title: "An Error Is found",
                                        text: "An error is happened please contact administrator",
                                        type: "error",
                                        confirmButtonText: "OK",
                                        padding: "2em",
                                        allowOutsideClick: false,
                                      }).then((res) => {
                                        window.location = window.location.href;
                                      });
                                    } else if (res[0] === "invalid-transaction") {
                                      swal({
                                        title: "Invalid Transaction",
                                        text: "This transaction is invalid or used already please try again",
                                        type: "error",
                                        confirmButtonText: "OK",
                                        padding: "2em",
                                        allowOutsideClick: false,
                                      }).then((res) => {
                                        window.location = window.location.href;
                                      });
                                    } else if (res.trans_id) {
                                      update_limit_remaining(data.paying_amount, res.trans_id)
                                      unset([
                                        "sell",
                                        "buy",
                                        "phone_number",
                                        "account_number",
                                      ]);
                                      $("#phoneAndAccountModel").modal("hide");
                                      $("button.back_btn").click(); //
                                      $(".buy_currency, .sell_currency")
                                        .children()
                                        .remove();
                                      $(".buy_currency, .sell_currency").text(
                                        "Select a token"
                                      );
                                      $("#sell, #buy").css("border", "none");
                                      display_receipt(res, response[0]);
                                    } else {
                                      swal({
                                        title: "An Error Is found",
                                        text: "An error is happened please contact administrator",
                                        type: "error",
                                        confirmButtonText: "OK",
                                        padding: "2em",
                                        allowOutsideClick: false,
                                      }).then((res) => {
                                        window.location = window.location.href;
                                      });
                                    }
                                  });
                              } else {
                                $("#phoneAndAccountModel").modal("show");
                              }
                            } else {
                              swal({
                                title: "Error found",
                                text: "An error occured, please try again later",
                                type: "error",
                                confirmButtonText: "Next",
                                padding: "2em",
                                allowOutsideClick: false,
                              });
                              window.location = window.location.href;
                            }
                          });
                        }
                      } else {
                        swal({
                          title: "Error found",
                          text: "An error occured, please try again later",
                          type: "error",
                          confirmButtonText: "Next",
                          padding: "2em",
                          allowOutsideClick: false,
                        });
                        window.location = window.location.href;
                      }
                    },
                  });
                },
              });
            } else {
              swal({
                title: `An error happen!`,
                text: `Something went wrong, please try agian!`,
                type: "error",
                confirmButtonText: "OK",
                padding: "2em",
                allowOutsideClick: false,
              }).then(() => {
                window.location = window.location.href;
              });
            }
          } else {
            Snackbar.show({
              text: lang("alert.__INVALID_ACCOUNT"),
              pos: "top-right",
              actionTextColor: "#fff",
              backgroundColor: "#e7515a",
              duration: 3000,
            });
          }
        })
      } else {
        Snackbar.show({
          text: lang("alert.__PAYOUT_ACCOUNT"),
          pos: "top-right",
          actionTextColor: "#fff",
          backgroundColor: "#e7515a",
          duration: 3000,
        });
      }
    });

    $("button.download_receipt").click(function (e) {
      e.preventDefault();
      html2canvas($("#receipt_displayer"), {
        onrendered: function (canvas) {
          var imgageData = canvas.toDataURL("image/png");
          var newData = imgageData.replace(
            /^data:image\/png/,
            "data:application/octet-stream"
          );
          var a = $("<a>")
            .attr("href", newData)
            .attr("download", "receipt.png")
            .appendTo("body");
          a[0].click();
          a.remove();
        },
      });
    });

    function validate_account_number(account, type = "us dollar") {
      if (type == "us dollar") {
        if (account[0].toLowerCase() === "u" && account.length === 9) {
          return true;
        }
        return false;
      } else {
        return true;
      }
    }

    function get_type() {
      let curr_name = selected_currency("sell", "name");
      if (curr_name.toLowerCase() === "pm") {
        return "perfect money";
      } else if (curr_name.toLowerCase() === "usd") {
        return "us dollar";
      }
    }

    function get_api_type() {
      switch (api_type) {
        case 'merchant':
          return "us dollar";
          break;
        case 'perfect money':
          return "perfect money";
          break;
        case 'salaam bank':
          return "salaam bank";
          break;
        default:
          return null;
          break;
      }
    }

    function fill_buy_input() {
      if (
        selected_currency("sell") &&
        selected_currency("buy") &&
        $("#sell").val().trim() !== ""
      ) {
        let buy = get_currency(selected_currency("buy"));
        let max = rnd_num(buy.reserve) * ((100 - rnd_num(buy.liquidity)) / 100);

        if (
          Number($("#sell").val()) >= rnd_num(Number(buy.minimum_amount)) &&
          Number($("#sell").val()) <= max
        ) {
          return true;
        } else {
          Snackbar.show({
            text: `Use amount greater than ${rnd_num(
              buy.minimum_amount
            )} or less than ${max}`,
            pos: "top-right",
            actionTextColor: "#fff",
            backgroundColor: "#e7515a",
            duration: 3000,
          });
          return false;
        }
      }
      return false;
    }

    $(".select_currency").click(function (e) {
      e.preventDefault();
      selecting = $(this).data("state");
      $("ul.currency_list").children().remove();
      currencys.forEach((currency) => {
        let sellable =
          JSON.parse(currency.checkbox).sellable == "true" ? true : false;
        let buyable =
          JSON.parse(currency.checkbox).buyable == "true" ? true : false;
        if (
          selecting === "sell" &&
          selected_currency("buy") !== currency.name &&
          sellable
        ) {
          $("ul.currency_list").append(
            currency_list(
              currency.icon,
              currency.name,
              currency.currency,
              currency.id
            )
          );
        } else if (
          selecting === "buy" &&
          selected_currency("sell") !== currency.name &&
          buyable
        ) {
          $("ul.currency_list").append(
            currency_list(
              currency.icon,
              currency.name,
              currency.currency,
              currency.id
            )
          );
        }
      });
      $("#currencyModel").modal("show");
    });

    function show_sell_detail() {
      let sell = get_currency(selected_currency("sell"));
      let buy = get_currency(selected_currency("buy"));

      let buy_amount = Number($("#buy").val());
      let sell_amount = Number($("#sell").val());

      let rate = 0;
      for (factor of JSON.parse(buy.currency_factor)) {
        if (
          sell_amount >= Number(factor.minimum_amount) &&
          sell_amount <= Number(factor.maximum_amount)
        ) {
          rate = Number(factor.percent_charge);
          payout_charge = Number(factor.payout_charge);
          break;
        }
      }

      calculate_ponus_and_discount_amount({ sell_amount, charge_rate:rate }, ({_ponus, _discount}) => {
        $("#sell_minimum").text(display_rnd(buy.minimum_amount));
        $("#sell_maximum").text(
          display_rnd(rnd_num(buy.reserve) * ((100 - rnd_num(buy.liquidity)) / 100))
        );
        $("#sell_rate").text(display_rnd(rate) + "%");
        $("#sell_rate").data("charge", display_rnd(rate));
        let receiving_amount = (Number(rate) / 100) * Number($("#sell").val());
        let final_amount = (sell_amount - receiving_amount) + _discount;
        $("#buy").val(display_rnd(final_amount));
        $(".sell_detail").show();

        discount_amount = _discount;
        ponus_amount = _ponus;
      })
    }

    function selected_currency_el(img, name) {
      return `
          <img src="${img}" width="20" alt="">
          <span style="display:inline-block;margin-left:10px"> ${name} </span>
      `;
    }

    function currency_list(img, name, currency, id = "") {
      return `
      <li data-currency_id ="${id}" data-name="${currency}">
          <img src="${img}" alt="">
          <div class="currency">
              <div class="currency_sign"> ${name} </div>
              <div class="currency_name"> ${currency} </div>
          </div>
      </li>
      `;
    }

    function reset() {
      $("#sell").val("");
      $("#buy").val("");
      $("#payment_method").val("");
      $("#account_number").val("");
      $("#phone_number").val("");

      $("button.back_btn").click(); //
      $(".buy_currency, .sell_currency").children().remove();
      $(".buy_currency, .sell_currency").text("Select a token");

      $("#sell_minimum").text("");
      $("#sell_maximum").text("");
      $("#sell_rate").text("");
      $("#buy").val("");
      $(".sell_detail").hide();
    }

    // inputs
    function file_upload() {
      return `
        <div class="upload">
            <input type="file" id="proof_image" class="dropify" data-max-file-size="2M" />
        </div>
      `;
    }
  });

  function payment_method_option(inputs, approve = false) {
    let option = `<option selected value='null'> ${lang(
      "label.__SELECT_METHOD"
    )} </option>`;
    inputs.forEach((input) => {
      if (approve) {
        if (input.field_approve) {
          option += `<option value="${input.field_name}" 
              data-input_type="${input.field_type}" 
              data-send_guard="${input.field_instruction}"
              data-api_type="${input.payment_api}"
              data-prefix="${input.field_prefix}"
              data-account="${input.field_account}"> ${input.field_name} </option>`;
        }
      } else {
        if (!input.field_approve && input.payment_visibility === "show") {
          option += `<option value="${input.field_name}" 
                data-input_type="${input.field_type}" 
                data-send_guard="${input.field_instruction}" 
                data-api_type="${input.payment_api}"
                data-prefix="${input.field_prefix}"
                data-account="${input.field_account}"> ${input.field_name} </option>`;
        }
      }
    });
    return option;
  }

  function withdrawal_method() {
    buy_curr = JSON.parse(
      get_currency(selected_currency("buy")).sending_detail
    );
    if (buy_curr.length === 1) {
      $(".div-account").children().remove();
      $(".div-account").append(
        `<label for="account_number">${buy_curr[0].field_name}</label> <span class="float-right" id="amountToReceive"></span>
        <input type="${buy_curr[0].field_type}" class="form-control" id="account_number" data-prefix="${buy_curr[0].field_prefix}"
        data-method_name="${buy_curr[0].field_name}" placeholder="Enter ${buy_curr[0].field_name.toLowerCase()}" value="${buy_curr[0].field_prefix}">
        `
      );
    } else {
      $("#withdrawal_method").append(payment_method_option(buy_curr));
    }
    $("#phoneAndAccountModel").modal("show");
  }

  function get_currency(name) {
    return currencys.filter((currency) => currency.name === name).first();
  }

  function selected_currency(type, data = "currency") {
    if (type === "sell") {
      return $(".sell_currency").data(data);
    } else if (type === "buy") {
      return $(".buy_currency").data(data);
    }
  }

  function display_receipt(data, destination_name = "") {
    data.status == "sent"
      ? $("#_status").text("SUCCESSFUL").css("color", "green")
      : $("#_status").text("PENDING").css("color", "tomato");
    $("#_trans_id").text(data.trans_id);
    $("#_date").text(data.date);
    $("#_method").text(data.deposit_with);
    $("#_phone").text(data.deposit_number);
    $("#_destination_name").text(destination_name);
    $("#_receive_currency").text(data.buy);
    $("#_account").text(data.withdrawal_number);
    $("#_amount").text(data.paying_amount);
    $("#receiptModal").modal("show");
  }
