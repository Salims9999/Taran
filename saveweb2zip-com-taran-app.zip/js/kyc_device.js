let limit = null;

$(document).ready(function () {
    $("button.connect_btn").prop("disabled", true);

    let kycStore = JSON.parse(localStorage.getItem("kycDevice"));
    if (!kycStore) {
        $("#kycDeviceModal").modal("show");
        $("button.connect_btn").prop("disabled", false);
    } else {
        $.ajax({
            type: "POST",
            url: "/client/kyc-device/check",
            data: JSON.stringify(kycStore),
            dataType: "JSON",
            success: function (response) {
                if (response.msg === "not found") {
                    localStorage.removeItem("kycDevice");
                    $("#kycDeviceModal").modal("show");
                    $("button.connect_btn").prop("disabled", false);
                } else {
                    limit = response;
                    $("button.connect_btn").prop("disabled", false);
                }
            },
        });
    }

    // register device
    $("#kyc_provider").change(function (e) {
        e.preventDefault();
        const prefix = $("#kyc_provider option:selected").data("prefix");
        $("#kyc_phone_number").data("prefix", prefix);
        $("#kyc_phone_number").val(prefix);
    });

    $("#kyc_phone_number").on("input", function () {
        let value = $(this).val();
        let prefix = $(this).data("prefix");

        if (!value.startsWith(prefix)) {
            $(this).val(prefix);
        }
    });

    $("button.kycDeviceRegister").click(function (e) {
        e.preventDefault();
        let validate = validate_form_inputs([
            "kyc_provider",
            "kyc_phone_number",
        ]);
        if (validate) {
            $("button.kycDeviceRegister").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "/client/kyc-device/register",
                data: JSON.stringify(validate),
                dataType: "JSON",
                success: function (response) {
                    $("button.kycDeviceRegister").prop("disabled", false);
                    $(".phone-err").hide();

                    if (response.msg === "A-N-N-F") {
                        $(".phone-err").show();
                    } else {
                        if (response.otp_code) {
                            $("#kycDeviceOtpPhone").val(response.phone);
                            $("#kycDeviceOtpModal").modal("show");
                            $("#kycDeviceModal").modal("hide");
                        } else {
                            localStorage.setItem(
                                "kycDevice",
                                JSON.stringify({
                                    provider: response.provider,
                                    phone: response.phone,
                                })
                            );
                            limit = response;
                            $("#kycDeviceModal").modal("hide");
                        }
                    }
                },
            });
        }
    });

    // check otp
    $("button.kycDeviceOtpCheck").click(function (e) {
        e.preventDefault();
        let validate = validate_form_inputs([
            "kycDeviceOtpPhone",
            "kyc_otp_code",
        ]);
        if (validate) {
            $("button.kycDeviceOtpCheck").prop("disabled", true);
            $.ajax({
                type: "POST",
                url: "/client/kyc-device/check-otp",
                data: JSON.stringify(validate),
                dataType: "JSON",
                success: function (response) {
                    $("button.kycDeviceOtpCheck").prop("disabled", false);
                    $("div.kycDeviceOtp-err").hide();
                    if (response.error) {
                        $("div.kycDeviceOtp-err").text(response.msg).show();
                    } else {
                        localStorage.setItem(
                            "kycDevice",
                            JSON.stringify({
                                provider: response.provider,
                                phone: response.phone,
                            })
                        );
                        limit = response;
                        $("#kycDeviceOtpModal").modal("hide");
                        window.location = window.location.href;
                    }
                },
            });
        }
    });

    function validate_form_inputs(inputs, selector = "#") {
        let inputs_value = {};
        for (input of inputs) {
            let value = null;
            try {
                value = $(`${selector}${input}`).val().trim();
                value = value === "null" ? null : value;
            } catch (error) {
                value = $(`${selector}${input}`).val();
            }

            if (value == "" || value == null) {
                $(`${selector}${input}`).css("border", "1px solid red");
                $(`${selector}${input}`).focus();
                const inputName =
                    $(`${selector}${input}`).data("inputName") ?? input;
                Snackbar.show({
                    text: `the ${inputName} field is required`,
                    pos: "top-right",
                    actionTextColor: "#fff",
                    backgroundColor: "#e7515a",
                    duration: 3000,
                });
                inputs_value = null;
                break;
            } else {
                $(`${selector}${input}`).css(
                    "border",
                    "1px solid rgba(0,0,0,.2)"
                );
                error = true;
                inputs_value[input] = $(`${selector}${input}`).val();
            }
        }
        return inputs_value;
    }
    // register device

    // payment method configuration

    // -- show registered number as default
    $("#payment_method").change(function (e) {
        e.preventDefault();
        $("#phone_number").prop("disabled", false);
        if (checkPhoneNumber("deposit")) {
            $("#phone_number").val(limit.phone).prop("disabled", true);
        }
    });

    // -- show registered provider as default
    $("#phoneAndAccountModel").on("shown.bs.modal", function () {
        if (limit.customer_type !== "secondary") {
            let sltedCurrency = selected_currency("sell");
            if (sltedCurrency.toLowerCase() === "us dollar") {
                $("#payment_method")
                    .children("option")
                    .each((index, option) => {
                        let value = $(option).val().toLowerCase();
                        value = value === "evc plus" ? "hormuud" : value;
                        if (
                            value !== limit.provider.toLowerCase() &&
                            value !== "null"
                        ) {
                            $(option).remove();
                        }
                    });
            }
        }
    });

    // withdrawal method configuration

    // -- show registered number as default
    $("#withdrawal_method").change(function (e) {
        e.preventDefault();
        $("#account_number").prop("disabled", false);
        if (checkPhoneNumber("withdrawal")) {
            $("#account_number").val(limit.phone).prop("disabled", true);
        }
    });

    // -- show registered provider as default
    $("#phoneAndAccountModel").on("shown.bs.modal", function () {
        if (limit.customer_type !== "secondary") {
            let sltedCurrency = selected_currency("sell");
            if (sltedCurrency.toLowerCase() === "perfect money") {
                $("#withdrawal_method")
                    .children("option")
                    .each((index, option) => {
                        let value = $(option).val().toLowerCase();
                        value = value === "evc plus" ? "hormuud" : value;
                        if (
                            value !== limit.provider.toLowerCase() &&
                            value !== "null"
                        ) {
                            $(option).remove();
                        }
                    });
            }
        }
    });
});

function checkPhoneNumber(state) {
    if (limit.customer_type !== "secondary") {
        let sltedCurrency = selected_currency("sell");
        if (state === "deposit") {
            let value = $("#payment_method").val().toLowerCase();
            value = value === "evc plus" ? "hormuud" : value;
            return (
                sltedCurrency.toLowerCase() === "us dollar" &&
                value === limit.provider.toLowerCase()
            );
        } else if (state === "withdrawal") {
            let value = $("#withdrawal_method").val().toLowerCase();
            value = value === "evc plus" ? "hormuud" : value;
            return (
                sltedCurrency.toLowerCase() === "perfect money" &&
                value === limit.provider.toLowerCase()
            );
        }
    } else {
        return false;
    }
}

function checkDepositProceed(phoneNumber, callback) {
    let inputValue = $("#sell").val();
    let sltedCurrency = selected_currency("sell");

    if (limit.customer_type !== "secondary") {

        if (
            Number(inputValue) > Number(limit.remaining) &&  Number(limit.remaining) !== -1 &&
            sltedCurrency.toLowerCase() === "us dollar"
        ) {
            window.location = window.location.href;
        }

        if (
            sltedCurrency.toLowerCase() === "us dollar" &&
            phoneNumber !== limit.phone
        ) {
            Snackbar.show({
                text: "Invalid phone number provided",
                pos: "top-right",
                actionTextColor: "#fff",
                backgroundColor: "#e7515a",
                duration: 3000,
            });
        } else {
            callback();
        }
    } else {
        callback();
    }
}

function checkWithdrawalProceed(phoneNumber, callback) {
    if (limit.customer_type !== "secondary") {
        let sltedCurrency = selected_currency("sell");
        if (
            sltedCurrency.toLowerCase() === "perfect money" &&
            phoneNumber !== limit.phone
        ) {
            Snackbar.show({
                text: "Invalid phone number provided",
                pos: "top-right",
                actionTextColor: "#fff",
                backgroundColor: "#e7515a",
                duration: 3000,
            });
        } else {
            callback();
        }
    } else {
        callback();
    }
}

function checkLimitAmount(callback) {
    let inputValue = $("#sell").val();
    let sltedCurrency = selected_currency("sell");

    if (
        sltedCurrency.toLowerCase() === "us dollar" &&
        Number(limit.remaining) === -1
    ) {
        callback();
    } else {
        if (
            sltedCurrency.toLowerCase() === "us dollar" &&
            Number(inputValue) > Number(limit.remaining)
        ) {
            Snackbar.show({
                text: `You have got a limit of $${limit.limit_amount} per day and the remaining amount is $${limit.remaining}`,
                pos: "top-right",
                actionTextColor: "#fff",
                backgroundColor: "#e7515a",
                duration: 3000,
            });
            $("#phoneAndAccountModel").modal("hide");
            $("#sell").val(limit.remaining).trigger("blur");
        } else {
            callback();
        }
    }
}

function update_limit_remaining(amount, id) {
    $.ajax({
        type: "POST",
        url: "/client/kyc-device/update",
        data: JSON.stringify({
            ...limit,
            used: amount,
        }),
        dataType: "JSON",
        success: function (response) {
            console.log(response);
        },
    });
}
