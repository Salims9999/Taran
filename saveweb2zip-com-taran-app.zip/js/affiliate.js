let affiliate = null;

$(document).ready(function () {
    const _affiliate_code = get_request("affiliate");

    if (_affiliate_code) {
        sessionStorageCode()
            .then((res) => {
                affiliate_code = res.code;
            })
            .catch((e) => {
                if (!e) {
                    let url = `${window.location.origin}/${window.location.pathname}`;
                    window.history.pushState("", "", url);
                }
            });
    }

    function sessionStorageCode() {
        return new Promise((resolve, reject) => {
            let code = sessionStorage.getItem("affiliate");
            if (!code) {
                $.ajax({
                    type: "GET",
                    url: `api/affiliate/visit/${_affiliate_code}`,
                    dataType: "JSON",
                    success: function (response) {
                        if (response.code) {
                            sessionStorage.setItem(
                                "affiliate",
                                JSON.stringify(response)
                            );
                            affiliate = response;
                            resolve(response);
                        }
                        reject(false);
                    },
                    error: function (err) {
                        reject(err);
                    },
                });
            } else {
                affiliate = JSON.parse(code);
                resolve(JSON.parse(code));
            }
        });
    }

    function get_request(name) {
        if (
            (name = new RegExp(
                "[?&]" + encodeURIComponent(name) + "=([^&]*)"
            ).exec(location.search))
        )
            return decodeURIComponent(name[1]);
    }
});

function calculate_ponus_and_discount_amount(
    { sell_amount, charge_rate },
    callback
) {
    if (affiliate) {
        let profit_amount = (Number(charge_rate) / 100) * Number(sell_amount);
        let discount_amount =
            (Number(affiliate.discount) / 100) * Number(profit_amount);
        let ponus_amount =
            (Number(affiliate.ponus) / 100) * Number(profit_amount);
        callback({
            _ponus: ponus_amount,
            _discount: discount_amount,
        });
        return true;
    }
    callback({
        _ponus: 0,
        _discount: 0,
    });
}
