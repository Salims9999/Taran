let promo_code = null;
let isPromoCodeUsed = false;
let customerNote = [];
let tac = [];

$(document).ready(function () {
  $("#usePromoCode").click(function (e) {
    e.preventDefault();
    $(".codeInput").show();
  });

  $("button.check-btn").click(function (e) {
    e.preventDefault();
    $.ajax({
      type: "GET",
      url: `/client/promo_code/check?code=${$("#promoCode").val().trim()}`,
      dataType: "JSON",
      success: function (response) {
        $("#errorBox").hide();
        $("#successBox").hide();
        if (response === false) {
          $("#errorBox").show();
        } else if (selected_currency("buy", "id") === response.buy_currency) {
          promo_code = response;
          $("#successBox").show();
          $("button.check-btn").text("USE NOW").css({
            "background-color": "#44CF9C",
            border: "1px solid #44CF9C",
            "box-shadow": "none",
          });
          $("button.check-btn").addClass("usePromoCode-btn");
          $("button.check-btn").removeClass("check-btn");
        } else {
          $("#errorBox").show();
        }

        console.log(selected_currency("buy", "id") === response.buy_currency);
      },
    });
  });

  $(document).on("click", ".usePromoCode-btn", function () {
    if (!isPromoCodeUsed) {
      let sell_amount = Number($("#sell").val());
      let buy_amount = Number($("#buy").val());
      let charge = rnd_num(sell_amount - buy_amount);
      let promo_charge = rnd_num((Number(promo_code.amount) / 100) * charge);
      $("#buy").val(promo_charge + buy_amount);
      isPromoCodeUsed = true;
      promoCode = promo_code;
      $(".usePromoCode-btn")
        .removeClass("usePromoCode-btn")
        .text("USED")
        .prop("disabled", true);
    }
  });

  // notes
  $.ajax({
    type: "GET",
    url: "/client/notes",
    dataType: "JSON",
    async: true,
    success: function (response) {
      response.forEach(note => {
        note.title === 'terms and condition' ? tac.push(note) : customerNote.push(note)
      })
      terms_and_condition()
    },
  });

  function terms_and_condition(){
    if (tac.length > 0 && tac[0].status === 'active') {
      $('.tacBox').show()
    } else {
      tac_check = true
    }
  }

  $('.tacLink').click(function (e) { 
    e.preventDefault();
    let note = tac[0]
    $("#customerNoteModel div.modal-body").children().remove()
    $("#customerNoteModel div.modal-body").append(note.content);
    $("#customerNoteModel").modal('show')
  });

  $('input#tacInput').change(function (e) { 
    e.preventDefault();
    localStorage.setItem('terms_and_condition', $('input#tacInput').is(':checked'))
    if ($('input#tacInput').is(':checked')) {
      tac_check = true
    }
  });

  if (localStorage.getItem('terms_and_condition') === 'true') {
    $('input#tacInput').prop('checked', true)
    tac_check = true
  } else {
    $('input#tacInput').prop('checked', false)
  }

});

function isNoteToShow(callback) {
  checkLimitAmount(() => {
    if (customerNote.length > 0) {
      let note = customerNote[0];
      if (note.status === "active") {
        $("#customerNoteModel div.modal-body").children().remove()
        $("#customerNoteModel div.modal-body").append(note.content);
        if (note.closable === "no") {
          $("#customerNoteModel .closableBtn").hide();
          $("#customerNoteModel").modal({
            backdrop: "static",
            keyboard: false,
          });
        } else {
          $("#customerNoteModel").modal('show')
          $('#customerNoteModel').on('hidden.bs.modal', function (e) { callback() })
        }
        return "";
      }
    }
    callback();
  })
}
